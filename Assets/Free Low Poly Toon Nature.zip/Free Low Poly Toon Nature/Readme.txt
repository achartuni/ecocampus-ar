Free Low Poly Toon Nature


These assets are part of the "Toon Nature Set"  http://u3d.as/mDD

The package contains:

- 2x plants
- Tree
- Grass
- Rock


Thank you for downloading!
Please rate if you like it.


Twitter: https://twitter.com/TinySot
Facebook: https://www.facebook.com/TinySot
